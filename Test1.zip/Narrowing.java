class Narrowing{
	public static void main( String [] args){
		
		System.out.println("********Narrowing********");

		int  a=50;
		short b=(short)a;
		System.out.println(" "+b);	
		double d=50.56565656;
		float f=(float)d;
		System.out.println(" "+f);
		/*char ch=65;
		short m=(char)ch;
		System.out.println(" "+m);*/
		double a2=50.56565656;
		int y=(int)a2;
		System.out.println(" "+y);
		float g=50.5656f;
		int h=(int)g;
		System.out.println(" "+h);

	}
}