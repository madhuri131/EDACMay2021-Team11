import java.util.*;
class Test5{
	public static void main(String [] args){
		
			Scanner sc = new Scanner(System.in);
			int a[] = new int[n];
				System.out.println("Enter Array Elements :  ");
				int i= sc.nextInt();
				
				
    
			
	}
}