class Typecast{
	public static void main( String [] args){
		
		System.out.println("********Widening********");

		char ch='A';
		int a=ch;
		System.out.println(" "+a);	
		short sh=8;
		int a1=sh;
		System.out.println(" "+a1);
		int b=50;
		float f=b;
		System.out.println(" "+f);
		int c=50;
		double d=c;
		System.out.println(" "+d);
		long l=800;
		double k=l;
		System.out.println(" "+k);
		float m=50.56666f;
		double n=m;
		System.out.println(" "+n);

	}
}