
class Program {
    public static void main(String[] args) {
		for(int i=1;i<=5;i++)
		{
			for(int j=1;j>=i;j--)
				{
				
				if(i<=j)
				{
				System.out.print(" "+(char)(i+64));}
				else
				{
					System.out.print(" "+(char)(j+64));
				}
			}
			System.out.println();
		}
    }
}
