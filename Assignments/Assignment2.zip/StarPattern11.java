class StarPattern11
{
	public static void main(String args[])
	{
		int i,j,k,z=5;
		for(i=1;i<=6;i++)
		{
			for(j=1;j<=i;j++)
			{
				System.out.print("*");
			}
			for(k=1;k<=i;k++)
			{
				System.out.print(" ");
				
			}
			System.out.println(" ");
			
		}
	}
}