class Program{
    public static void main( String [] args) {
        float radius =7.5f;
        float PI=3.14f;
        double area;
        double parimeter;

        area = PI * radius * radius;
        System.out.println("Area of Circle : "+area);

        parimeter = 2 * PI * radius;
        System.out.println("parimeter of Circle : "+parimeter);
    }
} 
    
    