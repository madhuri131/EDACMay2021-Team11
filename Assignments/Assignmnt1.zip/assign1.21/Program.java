import java.util.*;

class Program {
    public static void main(String [] args){
        Scanner input = new Scanner( System.in );
        System.out.print("Enter a decimal number : ");
        int num =input.nextInt();
        int rem;
        String str = " ";
        char digit[] = {'0','1','2','3','4','5','6','7'};
        while(num > 0){
            rem = num % 8;
            str=digit[rem]+str; 
            num/=8;
        }
        System.out.println("Dec to Octal number : "+str);
       }     
    }   

