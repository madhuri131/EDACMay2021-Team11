import java.util.*;
class Program{
    public static void main( String args [] ) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter first number : ");
        int i = sc.nextInt();
        System.out.println("Enter Second number : ");
        int j = sc.nextInt();
        System.out.println("Enter Third number : ");
        int k = sc.nextInt();

        int avg = (i+j+k)/3;
        System.out.println("Average : " +avg);
    }
}
