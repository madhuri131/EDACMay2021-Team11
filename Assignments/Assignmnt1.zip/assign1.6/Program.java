import java.util.*;
class Program{
    public static void main( String args [] ) {
        Scanner sc = new Scanner(System.in);
        
        System.out.println("Enter first number : ");
        int i = sc.nextInt();
        System.out.println("Enter Second number : ");
        int j = sc.nextInt();

        int sum = i + j ;
        int sub = i - j ;
        int mul = i * j ;
        int div = i / j ;
        System.out.println("Sum  : "+sum);
        System.out.println("Sub  : "+sub);
        System.out.println("Mul  : "+mul);
        System.out.println("Div  : "+div);
 
    }
}