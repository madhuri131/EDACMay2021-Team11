import java.util.*;
class Program{
    public static void main( String args [] ) {
        int i,j;
        for ( i = 4 ; i<=4 ;i++){

            for ( j = 25; j<=25 ;j++){
                System.out.println( i+ " * "+j);

            } 
        }
    }
}
