import java.util.*;
class Program{
    public static void main( String args [] ) {
        //Scanner sc = new Scanner(System.in);
        int i,j,k;

        for(i = 8 ; i<=10 ; i++){

            for(j=1;j<=i;j++){
                k=i*j;
                System.out.println(i+ "*" +j+ "="+k);

            }
            System.out.println(j);
         
        }    
}
        
    }
    