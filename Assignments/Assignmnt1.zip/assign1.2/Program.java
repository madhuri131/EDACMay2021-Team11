class Program{
    public static void main( String args [] ) {
        int i =74; 
        int j  =36;
        int res = i +j; 
        System.out.println("74+36 ="+res);
        
        
    }
}