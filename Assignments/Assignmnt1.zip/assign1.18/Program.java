import java.util.*;

class Program {
    public static void main(String[] args) {
    
        String binaryNumber1 = "1010", binaryNumber2 = "1010";
       
        Integer num1 = Integer.parseInt(binaryNumber1, 2);
        Integer num2 = Integer.parseInt(binaryNumber2, 2);
      
        Integer result = num1 * num2;
        
        System.out.println(Integer.toBinaryString(result));
      
       }
      
      }   