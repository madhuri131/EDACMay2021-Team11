import java.util.*;
 /*1. 
class Program{
    public static void main( String args [] ) {
          
        int i = 2;
        int j = 3;
        System.out.println(Integer.toBinaryString(i));
        System.out.println(Integer.toBinaryString(j));
        System.out.println("addition : "+Integer.toBinaryString(i+j));

        //System.out.println(Integer.toHexString(2));
        //System.out.println(Integer.toOctalString(10));        */

/*2.
        int a,temp;
        int i=1;
        temp = 0;
        System.out.println( " Enter Binary Number : ");
        Scanner sc = new Scanner(System.in);
        a = sc.nextInt();
        while(a!=0){
            temp=temp+((2^i) * (a%10));
            a=a/10;
            i++;
        }
        System.out.println(temp);
    }  
} */


class Program {
public static void main(String[] args) {

    String binaryNumber1 = "1010", binaryNumber2 = "1010";
   
    Integer num1 = Integer.parseInt(binaryNumber1, 2);
    Integer num2 = Integer.parseInt(binaryNumber2, 2);
  
    Integer result = num1 + num2;
    
    System.out.println(Integer.toBinaryString(result));
  
   }
  
  }   
/*
  int a,temp;
        int i=1;
        temp = 0;
        System.out.println( " Enter Binary Number : ");
        Scanner sc = new Scanner(System.in);
        a = sc.nextInt();
  while(a!=0){
			
    int k = a%10;
    double power = Math.pow(2,i);
    temp = temp + (k* (int)power);
    a= a/10;
    i++;
}

System.out.println(temp);
}  
}
*/